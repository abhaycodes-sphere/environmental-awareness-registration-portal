// =====================================================
// ENVIRONMENTAL AWARENESS REGISTRATION PORTAL
// Code.gs — Google Apps Script Backend
//
// ✅ FIXED VERSION — Works with standalone Apps Script
// =====================================================


// ══════════════════════════════════════════════════
// ★  STEP 1 — PASTE YOUR GOOGLE SHEET ID HERE  ★
//
// How to find it:
//   Open your Google Sheet → look at the URL:
//   https://docs.google.com/spreadsheets/d/  COPY_THIS_PART  /edit
//
//   Paste that ID below (replace the placeholder text)
// ══════════════════════════════════════════════════

var SHEET_ID   = "APNA_GOOGLE_SHEET_ID_YAHAN_PASTE_KARO";  // ← CHANGE THIS
var SHEET_NAME = "Registrations";                            // Sheet tab ka naam


// Column headers — order must match what frontend sends
var HEADERS = [
  "Timestamp",
  "Student Name",
  "Class",
  "School Name",
  "City",
  "State",
  "Parent Name",
  "Instagram ID"
];


// ── MAIN HANDLER ─────────────────────────────────────

function doGet(e) {

  // Safety check
  if (!e || !e.parameter) {
    return buildResponse("error", "No data received.");
  }

  try {

    // ✅ FIX: openById() instead of getActiveSpreadsheet()
    //    getActiveSpreadsheet() only works when script is BOUND to a sheet.
    //    Since this is a standalone script, we use openById().
    var spreadsheet = SpreadsheetApp.openById(SHEET_ID);
    var sheet       = spreadsheet.getSheetByName(SHEET_NAME);

    // Create sheet tab if it doesn't exist
    if (!sheet) {
      sheet = spreadsheet.insertSheet(SHEET_NAME);
    }

    // Add header row if sheet is empty
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(HEADERS);

      var headerRange = sheet.getRange(1, 1, 1, HEADERS.length);
      headerRange.setBackground("#166534");
      headerRange.setFontColor("#ffffff");
      headerRange.setFontWeight("bold");
      headerRange.setFontSize(11);
      sheet.setFrozenRows(1);
    }

    // Extract URL parameters sent by the frontend
    var params = e.parameter;

    var timestamp   = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });
    var studentName = sanitize(params.studentName  || "");
    var className   = sanitize(params.studentClass || "");
    var schoolName  = sanitize(params.schoolName   || "");
    var city        = sanitize(params.city         || "");
    var state       = sanitize(params.state        || "");
    var parentName  = sanitize(params.parentName   || "");
    var instagramId = sanitize(params.instagramId  || "");

    // Write the new row
    sheet.appendRow([
      timestamp,
      studentName,
      className,
      schoolName,
      city,
      state,
      parentName,
      instagramId
    ]);

    sheet.autoResizeColumns(1, HEADERS.length);

    return buildResponse("success", "Data saved successfully.");

  } catch (error) {
    Logger.log("Error: " + error.toString());
    return buildResponse("error", "Server error: " + error.toString());
  }
}


// ── UTILITY FUNCTIONS ─────────────────────────────────

function sanitize(value) {
  if (typeof value !== "string") return "";
  value = value.trim();
  value = value.replace(/<[^>]*>/g, "");
  return value;
}

function buildResponse(status, message) {
  var payload = JSON.stringify({ status: status, message: message });
  return ContentService
    .createTextOutput(payload)
    .setMimeType(ContentService.MimeType.JSON);
}


// ── TEST FUNCTION ─────────────────────────────────────
// Apps Script editor mein: oopar "testDoGet" select karo → Run dabao
// Sheet mein ek test row aa jaayegi agar sab sahi hai

function testDoGet() {
  var fakeEvent = {
    parameter: {
      studentName:  "Test Student",
      studentClass: "10th",
      schoolName:   "Test High School",
      city:         "Lucknow",
      state:        "Uttar Pradesh",
      parentName:   "Test Parent",
      instagramId:  "@teststudent"
    }
  };

  var result = doGet(fakeEvent);
  Logger.log(result.getContent());
}
